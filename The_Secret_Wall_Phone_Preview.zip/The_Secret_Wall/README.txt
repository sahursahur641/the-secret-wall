THE SECRET WALL — PHONE PREVIEW

This is a static preview, not the live multi-user version.
Posts and reactions are saved only in each visitor's own browser.
There is no shared database or secure moderation queue. Do not use this preview to collect real submissions.

To publish this preview, open https://app.netlify.com/drop and upload the extracted folder containing index.html.
A real public confession wall needs a database and secure moderation backend before inviting visitors.
